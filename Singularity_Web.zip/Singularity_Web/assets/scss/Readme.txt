The .scss (Sass) files are only available in the pro version.
You can buy it from: https://bootstrapmade.com/Singularity-free-bootstrap-html-template-corporate/



6 S's for a Software Company Website
Solutions: Delivering innovative software solutions tailored to meet the unique needs of your business.
Services: Offering a comprehensive range of IT services, including consulting, development, and support to ensure seamless operations.
Scalability: Designing software that grows with your business, ensuring it can handle increased demand and complexity.
Security: Implementing robust security measures to protect your data and maintain your trust.
Support: Providing exceptional customer support to help you navigate and optimize your software solutions.
Success: Committed to driving your business success through effective technology and expert guidance.